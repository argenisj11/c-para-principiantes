﻿namespace MemoryGame
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlCover1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlCover2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pnlCover3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pnlCover4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pnlCover5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pnlCover7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.pnlCover13 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.pnlCover10 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.pnlCover14 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.pnlCover11 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.pnlCover15 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.pnlCover12 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.pnlCover16 = new System.Windows.Forms.Panel();
            this.timerInit = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pnlCover6 = new System.Windows.Forms.Panel();
            this.pnlCover8 = new System.Windows.Forms.Panel();
            this.pnlCover9 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel16.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.pnlCover1);
            this.panel1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Location = new System.Drawing.Point(1, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(172, 169);
            this.panel1.TabIndex = 0;
            this.panel1.Tag = "1";
            // 
            // pnlCover1
            // 
            this.pnlCover1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover1.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover1.Location = new System.Drawing.Point(0, 0);
            this.pnlCover1.Name = "pnlCover1";
            this.pnlCover1.Size = new System.Drawing.Size(172, 169);
            this.pnlCover1.TabIndex = 2;
            this.pnlCover1.Tag = "1";
            this.pnlCover1.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.pnlCover2);
            this.panel2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Location = new System.Drawing.Point(179, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(172, 169);
            this.panel2.TabIndex = 1;
            this.panel2.Tag = "2";
            // 
            // pnlCover2
            // 
            this.pnlCover2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover2.Location = new System.Drawing.Point(0, 0);
            this.pnlCover2.Name = "pnlCover2";
            this.pnlCover2.Size = new System.Drawing.Size(172, 169);
            this.pnlCover2.TabIndex = 3;
            this.pnlCover2.Tag = "2";
            this.pnlCover2.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Controls.Add(this.pnlCover3);
            this.panel3.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Location = new System.Drawing.Point(357, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(172, 169);
            this.panel3.TabIndex = 2;
            this.panel3.Tag = "3";
            // 
            // pnlCover3
            // 
            this.pnlCover3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover3.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover3.Location = new System.Drawing.Point(0, 0);
            this.pnlCover3.Name = "pnlCover3";
            this.pnlCover3.Size = new System.Drawing.Size(172, 169);
            this.pnlCover3.TabIndex = 4;
            this.pnlCover3.Tag = "3";
            this.pnlCover3.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Location = new System.Drawing.Point(535, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(172, 169);
            this.panel4.TabIndex = 3;
            this.panel4.Tag = "4";
            // 
            // pnlCover4
            // 
            this.pnlCover4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover4.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover4.Location = new System.Drawing.Point(535, 3);
            this.pnlCover4.Name = "pnlCover4";
            this.pnlCover4.Size = new System.Drawing.Size(172, 169);
            this.pnlCover4.TabIndex = 5;
            this.pnlCover4.Tag = "4";
            this.pnlCover4.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Controls.Add(this.pnlCover5);
            this.panel5.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.Location = new System.Drawing.Point(1, 178);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(172, 169);
            this.panel5.TabIndex = 4;
            this.panel5.Tag = "5";
            // 
            // pnlCover5
            // 
            this.pnlCover5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover5.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover5.Location = new System.Drawing.Point(0, 0);
            this.pnlCover5.Name = "pnlCover5";
            this.pnlCover5.Size = new System.Drawing.Size(172, 169);
            this.pnlCover5.TabIndex = 6;
            this.pnlCover5.Tag = "5";
            this.pnlCover5.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel6.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel6.Location = new System.Drawing.Point(179, 178);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(172, 169);
            this.panel6.TabIndex = 2;
            this.panel6.Tag = "6";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel7.Controls.Add(this.pnlCover7);
            this.panel7.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel7.Location = new System.Drawing.Point(357, 178);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(172, 169);
            this.panel7.TabIndex = 2;
            this.panel7.Tag = "7";
            // 
            // pnlCover7
            // 
            this.pnlCover7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover7.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover7.Location = new System.Drawing.Point(0, 0);
            this.pnlCover7.Name = "pnlCover7";
            this.pnlCover7.Size = new System.Drawing.Size(172, 169);
            this.pnlCover7.TabIndex = 6;
            this.pnlCover7.Tag = "7";
            this.pnlCover7.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel8.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel8.Location = new System.Drawing.Point(535, 178);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(172, 169);
            this.panel8.TabIndex = 2;
            this.panel8.Tag = "8";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel9.Location = new System.Drawing.Point(1, 353);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(172, 169);
            this.panel9.TabIndex = 2;
            this.panel9.Tag = "9";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel13.Controls.Add(this.pnlCover13);
            this.panel13.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel13.Location = new System.Drawing.Point(1, 528);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(172, 169);
            this.panel13.TabIndex = 2;
            this.panel13.Tag = "13";
            // 
            // pnlCover13
            // 
            this.pnlCover13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover13.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover13.Location = new System.Drawing.Point(0, 0);
            this.pnlCover13.Name = "pnlCover13";
            this.pnlCover13.Size = new System.Drawing.Size(172, 169);
            this.pnlCover13.TabIndex = 6;
            this.pnlCover13.Tag = "13";
            this.pnlCover13.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel10.BackgroundImage")));
            this.panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel10.Controls.Add(this.pnlCover10);
            this.panel10.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel10.Location = new System.Drawing.Point(179, 353);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(172, 169);
            this.panel10.TabIndex = 2;
            this.panel10.Tag = "10";
            // 
            // pnlCover10
            // 
            this.pnlCover10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover10.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover10.Location = new System.Drawing.Point(0, 0);
            this.pnlCover10.Name = "pnlCover10";
            this.pnlCover10.Size = new System.Drawing.Size(172, 169);
            this.pnlCover10.TabIndex = 6;
            this.pnlCover10.Tag = "10";
            this.pnlCover10.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel14.BackgroundImage")));
            this.panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel14.Controls.Add(this.pnlCover14);
            this.panel14.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel14.Location = new System.Drawing.Point(179, 528);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(172, 169);
            this.panel14.TabIndex = 2;
            this.panel14.Tag = "14";
            // 
            // pnlCover14
            // 
            this.pnlCover14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover14.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover14.Location = new System.Drawing.Point(0, 0);
            this.pnlCover14.Name = "pnlCover14";
            this.pnlCover14.Size = new System.Drawing.Size(172, 169);
            this.pnlCover14.TabIndex = 6;
            this.pnlCover14.Tag = "14";
            this.pnlCover14.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel11.BackgroundImage")));
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel11.Controls.Add(this.pnlCover11);
            this.panel11.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel11.Location = new System.Drawing.Point(357, 353);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(172, 169);
            this.panel11.TabIndex = 2;
            this.panel11.Tag = "11";
            // 
            // pnlCover11
            // 
            this.pnlCover11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover11.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover11.Location = new System.Drawing.Point(0, 0);
            this.pnlCover11.Name = "pnlCover11";
            this.pnlCover11.Size = new System.Drawing.Size(172, 169);
            this.pnlCover11.TabIndex = 6;
            this.pnlCover11.Tag = "11";
            this.pnlCover11.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel15.BackgroundImage")));
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel15.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel15.Location = new System.Drawing.Point(357, 528);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(172, 169);
            this.panel15.TabIndex = 2;
            this.panel15.Tag = "15";
            // 
            // pnlCover15
            // 
            this.pnlCover15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover15.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover15.Location = new System.Drawing.Point(357, 525);
            this.pnlCover15.Name = "pnlCover15";
            this.pnlCover15.Size = new System.Drawing.Size(172, 169);
            this.pnlCover15.TabIndex = 6;
            this.pnlCover15.Tag = "15";
            this.pnlCover15.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel12.BackgroundImage")));
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel12.Controls.Add(this.pnlCover12);
            this.panel12.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel12.Location = new System.Drawing.Point(535, 353);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(172, 169);
            this.panel12.TabIndex = 2;
            this.panel12.Tag = "12";
            // 
            // pnlCover12
            // 
            this.pnlCover12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover12.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover12.Location = new System.Drawing.Point(0, 0);
            this.pnlCover12.Name = "pnlCover12";
            this.pnlCover12.Size = new System.Drawing.Size(172, 169);
            this.pnlCover12.TabIndex = 6;
            this.pnlCover12.Tag = "12";
            this.pnlCover12.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel16.BackgroundImage")));
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel16.Controls.Add(this.pnlCover16);
            this.panel16.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel16.Location = new System.Drawing.Point(535, 528);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(172, 169);
            this.panel16.TabIndex = 2;
            this.panel16.Tag = "16";
            // 
            // pnlCover16
            // 
            this.pnlCover16.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover16.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover16.Location = new System.Drawing.Point(0, 0);
            this.pnlCover16.Name = "pnlCover16";
            this.pnlCover16.Size = new System.Drawing.Size(172, 169);
            this.pnlCover16.TabIndex = 6;
            this.pnlCover16.Tag = "16";
            this.pnlCover16.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // timerInit
            // 
            this.timerInit.Interval = 5000;
            this.timerInit.Tick += new System.EventHandler(this.timerInit_Tick);
            // 
            // timer1
            // 
            this.timer1.Interval = 700;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pnlCover6
            // 
            this.pnlCover6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover6.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover6.Location = new System.Drawing.Point(179, 178);
            this.pnlCover6.Name = "pnlCover6";
            this.pnlCover6.Size = new System.Drawing.Size(172, 169);
            this.pnlCover6.TabIndex = 6;
            this.pnlCover6.Tag = "6";
            this.pnlCover6.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // pnlCover8
            // 
            this.pnlCover8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover8.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover8.Location = new System.Drawing.Point(535, 178);
            this.pnlCover8.Name = "pnlCover8";
            this.pnlCover8.Size = new System.Drawing.Size(172, 169);
            this.pnlCover8.TabIndex = 6;
            this.pnlCover8.Tag = "8";
            this.pnlCover8.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // pnlCover9
            // 
            this.pnlCover9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCover9.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pnlCover9.Location = new System.Drawing.Point(1, 353);
            this.pnlCover9.Name = "pnlCover9";
            this.pnlCover9.Size = new System.Drawing.Size(172, 169);
            this.pnlCover9.TabIndex = 6;
            this.pnlCover9.Tag = "9";
            this.pnlCover9.Click += new System.EventHandler(this.pnlCover_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(719, 705);
            this.Controls.Add(this.pnlCover15);
            this.Controls.Add(this.pnlCover9);
            this.Controls.Add(this.pnlCover8);
            this.Controls.Add(this.pnlCover6);
            this.Controls.Add(this.pnlCover4);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Memory Game";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel13;
        private Panel panel10;
        private Panel panel14;
        private Panel panel11;
        private Panel panel15;
        private Panel panel12;
        private Panel panel16;
        private Panel pnlCover13;
        private Panel pnlCover15;
        private Panel pnlCover12;
        private Panel pnlCover16;
        private Panel pnlCover11;
        private System.Windows.Forms.Timer timerInit;
        private System.Windows.Forms.Timer timer1;
        private Panel pnlCover14;
        private Panel pnlCover1;
        private Panel pnlCover2;
        private Panel pnlCover3;
        private Panel pnlCover4;
        private Panel pnlCover7;
        private Panel pnlCover5;
        private Panel pnlCover6;
        private Panel pnlCover8;
        private Panel pnlCover9;
        private Panel pnlCover10;
    }
}