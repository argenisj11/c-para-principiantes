﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MemoryGame
{
    public class Icon
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public Image Image { get; set; }
    }
}
